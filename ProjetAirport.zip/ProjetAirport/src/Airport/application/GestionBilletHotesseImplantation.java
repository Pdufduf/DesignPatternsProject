package Airport.application;

import java.util.Date;

import Airport.domain.Billet;
import Airport.domain.Client;
import Airport.domain.Hotesse;
import Airport.domain.Passager;
import Airport.domain.Vol;

public class GestionBilletHotesseImplantation implements GestionBilletHotesse{

	Hotesse hotesse = new Hotesse();
	@Override
	public void achatBillet(Date date, int numero, Passager passager, Vol vol) {
		Billet billet = new Billet();
		billet.setDate(date);
		billet.setNumero(numero);
		billet.setPassager(passager);
		billet.setVol(vol);
		billet.setClient(null);
		billet.setHotesse(hotesse);	}

	@Override
	public void annulerBillet(Date date, int numero, Passager passager, Vol vol) {
		Billet billet = new Billet();
		billet.setDate(null);
		billet.setNumero(0);
		billet.setPassager(null);
		billet.setVol(null);
		billet.setClient(null);
		billet.setHotesse(null);
	}

	@Override
	public void achatBilletClient(Client client) {
		// TODO Auto-generated method stub
		
	}

}
