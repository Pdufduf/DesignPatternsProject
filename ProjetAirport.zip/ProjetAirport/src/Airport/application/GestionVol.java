package Airport.application;

import Airport.domain.Billet;

public interface GestionVol {

	public void ouvrirVol();
	public void fermerVol();
}
