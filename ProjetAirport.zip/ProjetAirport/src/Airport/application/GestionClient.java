package Airport.application;

public interface GestionClient {

	public void enregistrementClient(String nom, String prenom, String adresse, String telephone);
}
